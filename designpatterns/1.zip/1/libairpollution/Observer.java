
package designpatterns.libairpollution;

interface Observer{
    void update(double airPollutionIndex);
}

