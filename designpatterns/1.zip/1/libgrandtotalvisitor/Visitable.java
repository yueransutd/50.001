package designpatterns.libgrandtotalvisitor;

public interface Visitable {
    void accept(Visitor v);
}
