package designpatterns.libgeomvisitor;

public interface Visitable {
    void accept(Visitor v);
}

