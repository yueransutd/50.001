package designpatterns.libtrafficalert;

public interface Observer {
    void update(String message);
}
